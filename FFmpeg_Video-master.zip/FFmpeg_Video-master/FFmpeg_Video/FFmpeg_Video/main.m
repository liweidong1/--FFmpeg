//
//  main.m
//  FFmpeg_Video
//
//  Created by offcn_c on 16/5/10.
//  Copyright © 2016年 offcn_c. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
