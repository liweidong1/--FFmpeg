//
//  AppDelegate.h
//  FFmpeg_Video
//
//  Created by offcn_c on 16/5/10.
//  Copyright © 2016年 offcn_c. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

