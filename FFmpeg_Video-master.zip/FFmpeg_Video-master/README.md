演示：

![](https://github.com/ytdxxt10/FFmpeg_Video/raw/master/FFmpeg_Video/ffmpeg.gif)

**如果你觉得有用，就加个star吧😊**

**注意：**

** 1.代码只做到了将视频帧的解码，并没有涉及到音频，因此不会有声音出现 **

** 2. 参考KXmovie**

** 3. ffmpeg的编译已经写过一篇，不再赘述，使用时直接拖进项目中即可，需要添加的依赖库git上的项目也有所体现。**

